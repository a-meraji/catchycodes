import React from 'react'

function Works() {
  return (
    <div>Works</div>
  )
}

export default Works